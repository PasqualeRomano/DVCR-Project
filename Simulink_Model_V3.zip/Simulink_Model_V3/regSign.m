function y = regSign(x)

epsilon = 1;
y = tanh(x/epsilon);

end