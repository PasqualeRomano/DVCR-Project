 %extract data
  g   = data.gravity;
  M   = data.mass;
  Iz  = data.Iz;
  Lr  = data.Lr;
  Lf  = data.Lf;
  kv  = data.kv;
  %
  Byr = data.Byr;
  Cyr = data.Cyr;
  Dyr = data.Dyr;
  Eyr = data.Eyr;
  Kyr = data.Kyr;
  
  Byf = data.Byf;
  Cyf = data.Cyf;
  Dyf = data.Dyf;
  Eyf = data.Eyf;
  Kyf = data.Kyf;